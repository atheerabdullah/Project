package com.example.project21.Model;


import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Table
@Entity
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private Long id;

    @Size(min = 2)
    @Column(nullable = false, columnDefinition = "VARCHAR(255) CHECK (LENGTH(name) >= 2)")
    private String name;


    @NotNull(message = " Genre cannot be null")
    @Column(nullable = false, columnDefinition = "VARCHAR(255) check (genre='Drama' or genre='Action' or genre='Comedy')")
    private String genre;

    @NotNull(message = "Rating cannot be null")
    @DecimalMin(value = "1.0", message = "Rating must be latest 1.0")
    @DecimalMax(value = "5.0", message = "Rating cannot be more than 5.0")
    @Column(nullable = false, columnDefinition = "DECIMAL(3,1) CHECK (rating >= 1.0 AND rating <= 5.0)")
    private Double rating;



    @NotNull(message = "Duration cannot be null")
    @Min(value = 60, message = "Duration must be at least 60 minutes")
    @Column(nullable = false, columnDefinition = "INT CHECK (duration >= 60)")
    private Integer duration;



    //  key
    private Long directorId;



}
