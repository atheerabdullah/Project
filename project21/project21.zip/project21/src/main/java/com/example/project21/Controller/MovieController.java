package com.example.project21.Controller;


import com.example.project21.Model.Movie;
import com.example.project21.Service.MovieService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/movie")
@AllArgsConstructor
public class MovieController {


    private final MovieService movieService;


    @GetMapping("/getMovie")
    public ResponseEntity<List<Movie>> getAll() {
        List<Movie> movieList = movieService.getAllMovie();
        return ResponseEntity.status(HttpStatus.OK).body(movieList);
    }

    //find Movie By ID
    @GetMapping("/getMovieByID/{id}")
    public ResponseEntity<Movie> findMovieById(@PathVariable Long id) {
        Movie movie = movieService.findMovieById(id);
        return ResponseEntity.status(HttpStatus.OK).body(movie);
    }

    //  get Movie By Name
    @GetMapping("/findMovieByName/{name}")
    public List<Movie> findMovieByName(@PathVariable String name) {
        List<Movie> movies = movieService.findMovieByName(name);
        return movies;
    }

    // get name movie to get Duration time
    @GetMapping("/movies/{name}/duration")
    public ResponseEntity<Integer> getMovieDuration(@PathVariable String name) {
        Integer duration = movieService.getMovieDuration(name);
        if (duration != null) {
            return ResponseEntity.ok(duration);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // movie name and return the rate of the movie
    @GetMapping("/movies/{name}/rating")
    public ResponseEntity<Double> getMovieRating(@PathVariable String name) {
        Double rating = movieService.getMovieRating(name);
        if (rating != null) {
            return ResponseEntity.ok(rating);
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    //all movies with a height rating
    @GetMapping("/movies/rating/{rating}")
    public ResponseEntity<List<Movie>> getMoviesByRating(@PathVariable Double rating) {
        List<Movie> movies = movieService.getMoviesByRating(rating);
        if (!movies.isEmpty()) {
            return ResponseEntity.ok(movies);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // all movies with Genre

    @GetMapping("/movies/genre/{genre}")
    public ResponseEntity<List<Movie>> getMoviesByGenre(@PathVariable String genre) {
        List<Movie> movies = movieService.getMoviesByGenre(genre);
        if (!movies.isEmpty()) {
            return ResponseEntity.ok(movies);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // list movies to a specific director
    @GetMapping("/director/{directorId}")
    public List<Movie> getMoviesByDirectorId(@PathVariable Long directorId) {
        return movieService.getMoviesByDirectorId(directorId);
    }

    // get Director Name By Movie Name
    @GetMapping("/director/{movieName}")
    public String getDirectorNameByMovieName(@PathVariable String movieName) {
        return movieService.getDirectorNameByMovieName(movieName);
    }


    @PostMapping("/addMovie")
    public ResponseEntity addMovie(@RequestBody @Valid Movie movie) {
        movieService.addMovie(movie);
        return ResponseEntity.status(200).body("Movie added");

    }

    @PutMapping("/updateMovie/{id}")
    public ResponseEntity<Object> updatedMovie(@Valid @RequestBody Movie movie, @PathVariable Long id) {
        Movie updatedMovie = movieService.updateMovie(id, movie);
        return new ResponseEntity<>(updatedMovie, HttpStatus.OK);
    }

    @DeleteMapping("/deleteMovie/{id}")
    public ResponseEntity<Object> deleteMovie(@PathVariable Long id) {
        movieService.deleteMovie(id);
        return ResponseEntity.status(200).body("The Movie deleted ");
    }


}
