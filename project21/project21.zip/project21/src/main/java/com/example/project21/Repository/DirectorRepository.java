package com.example.project21.Repository;

import com.example.project21.Model.Director;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DirectorRepository extends JpaRepository<Director , Integer> {



}
