package com.example.project21.ControllerAdvice;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class ErrorDetails {

        @JsonProperty("field")
        private String field;

        @JsonProperty("message")
        private String message;

}
