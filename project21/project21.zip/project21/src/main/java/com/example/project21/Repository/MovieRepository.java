package com.example.project21.Repository;

import com.example.project21.Model.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {

    Movie findMovieById(Long id);

    List<Movie> findMovieByName(String name);

    Movie findMovieByNameEquals(String name);


    // getting the rate of movie
    @Query("SELECT m.rating FROM Movie m WHERE m.name = :name")
    Double findRatingByNameEquals(@Param("name") String name);

    //all movies with a height rating
    @Query("SELECT m FROM Movie m WHERE m.rating >= :rating")
    List<Movie> findMoviesByRatingGreaterThanEqual(@Param("rating") Double rating);

    // all movies find By Genre
    @Query("SELECT m FROM Movie m WHERE m.genre = :genre")
    List<Movie> findByGenre(@Param("genre") String genre);

    // list movies to a specific director
    @Query("SELECT m FROM Movie m WHERE m.directorId = :directorId")
    List<Movie> findByDirectorId(@Param("directorId") Long directorId);

    //

    @Query("SELECT d.name FROM Director d, Movie m WHERE m.name = :movieName AND m.directorId = d.id")
    String findDirectorNameByMovieName(@Param("movieName") String movieName);
}


