package com.example.project21.Service;


import com.example.project21.ApiException.ApiException;
import com.example.project21.ControllerAdvice.GlobalExceptionHandler;
import com.example.project21.Model.Director;
import com.example.project21.Repository.DirectorRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class DirectorService {

   private final DirectorRepository directorRepository;

        public List<Director> getAllDirectors() {
            return directorRepository.findAll();
        }

        public Director getDirectorById(Integer id) {
            return directorRepository.findById(id)
                    .orElseThrow(() -> new ApiException ("Director not found with id " + id));
        }

        public Director addDirector(Director director) {
            return directorRepository.save(director);
        }

        public Director updateDirector(Integer id, Director updatedDirector) {
            Director director = directorRepository.findById(id)
                    .orElseThrow(() -> new ApiException("Director not found with id " + id));
            director.setName(updatedDirector.getName());
            return directorRepository.save(director);
        }

        public void deleteDirector(Integer id) {
            Director director = directorRepository.findById(id)
                    .orElseThrow(() -> new ApiException ("Director not found with id " + id));
            directorRepository.delete(director);
        }
    }

