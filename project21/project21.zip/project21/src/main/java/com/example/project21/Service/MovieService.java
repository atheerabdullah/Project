package com.example.project21.Service;


import com.example.project21.Model.Movie;
import com.example.project21.Repository.MovieRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.ValidationException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@RequiredArgsConstructor
public class MovieService {


    @Autowired
    private final MovieRepository movieRepository;


    public List<Movie> getAllMovie() {
        return movieRepository.findAll();
    }

    public Movie findMovieById(Long id) {
        Movie movie = movieRepository.findMovieById(id);
        if (movie == null) {
            throw new EntityNotFoundException("Movie not found with id " + id);
        }
        return movieRepository.findMovieById(id);
    }

    // get movie by name

    public List<Movie> findMovieByName(String name) {
        List<Movie> movies = movieRepository.findMovieByName(name);
        if (movies.isEmpty()) {
            throw new EntityNotFoundException("Movie not found with name: " + name);
        }
        return movies;
    }

    // get Movie by Duration
    public Integer getMovieDuration(String name) {
        Movie movie = movieRepository.findMovieByNameEquals(name);
        if (movie == null) {
            throw new EntityNotFoundException("Movie not found with name: " + name);
        }
        return movie.getDuration();
    }


    //    return the rate of the movie
    public Double getMovieRating(String name) {
        Double rating = movieRepository.findRatingByNameEquals(name);
        if (rating == null) {
            throw new EntityNotFoundException("Rating not found for movie with name: " + name);
        }
        return rating;
    }

    //all movies with a height rating
    public List<Movie> getMoviesByRating(Double rating) {
        List<Movie> movies = movieRepository.findMoviesByRatingGreaterThanEqual(rating);
        if (movies.isEmpty()) {
            throw new EntityNotFoundException("No movies found with rating greater than or equal to: " + rating);
        }
        return movies;
    }
    // get All Movies By Genre
    public List<Movie> getMoviesByGenre(String genre) {
        return movieRepository.findByGenre(genre);
    }

    //list movies to a specific director
    public List<Movie> getMoviesByDirectorId(Long directorId) {
        return movieRepository.findByDirectorId(directorId);
    }
    // get Director Name By Movie Name
    public String getDirectorNameByMovieName(String movieName) {
        return movieRepository.findDirectorNameByMovieName(movieName);
    }
    

    public void addMovie(Movie movie) {
        movieRepository.save(movie);
    }

    public Movie updateMovie(Long id, Movie movie) {
        Movie updatedMovie = movieRepository.findMovieById(id);
        if (updatedMovie == null) {
            throw new EntityNotFoundException("Movie not found with id " + id);
        }
        if (movie.getName() != null) {
            updatedMovie.setName(movie.getName());
        }
        if (movie.getDuration() != null) {
            updatedMovie.setDuration(movie.getDuration());
        }
        if (movie.getGenre() != null) {
            updatedMovie.setGenre(movie.getGenre());
        }
        if (movie.getRating() != null) {
            updatedMovie.setRating(movie.getRating());
        }
        try {
            Movie savedMovie = movieRepository.save(updatedMovie);
            if (savedMovie == null) {
                throw new RuntimeException("Failed to update movie with id: " + id);
            }
            return savedMovie;
        } catch (ConstraintViolationException ex) {
            throw new ValidationException("Validation failed", ex);
        } catch (Exception ex) {
            throw new RuntimeException("Failed to update movie with id: " + id, ex);
        }
    }

    public void deleteMovie(Long id) {
        Movie movie = movieRepository.findMovieById(id);
        if (movie == null) {
            throw new EntityNotFoundException("Movie not found with id " + id);
        }
        movieRepository.delete(movie);
    }

}
