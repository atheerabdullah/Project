package com.example.project21.ControllerAdvice;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@RestControllerAdvice
@AllArgsConstructor
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Object> handleValidationException(MethodArgumentNotValidException ex) {
        List<ErrorDetails> errorDetailsList = new ArrayList<>();
        ex.getBindingResult().getFieldErrors().forEach(error -> {
            errorDetailsList.add(new ErrorDetails(error.getField(), error.getDefaultMessage()));
        });
        ErrorDetailsResponse errorDetailsResponse = new ErrorDetailsResponse(LocalDateTime.now(), HttpStatus.BAD_REQUEST, "Validation failed", errorDetailsList);
        return new ResponseEntity<>(errorDetailsResponse, HttpStatus.BAD_REQUEST);
    }
}




