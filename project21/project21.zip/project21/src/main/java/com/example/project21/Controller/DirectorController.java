package com.example.project21.Controller;

import com.example.project21.Model.Director;
import com.example.project21.Service.DirectorService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/v1/Director")
@AllArgsConstructor
public class DirectorController {

    private final DirectorService directorService;


    // get all
    @GetMapping("/directors")
    public List<Director> getAllDirectors() {
        return directorService.getAllDirectors();
    }

    // get by id
    @GetMapping("/directors/{id}")
    public ResponseEntity<Director> getDirectorById(@PathVariable(value = "id") Integer id) {
        Director director = directorService.getDirectorById(id);
        return ResponseEntity.ok().body(director);
    }

    @PostMapping("/directors")
    public Director createDirector(@Valid @RequestBody Director director) {
        return directorService.addDirector(director);
    }


    // update

    @PutMapping("/directors/{id}")
    public ResponseEntity<Director> updateDirector(@PathVariable(value = "id") Integer id, @Valid @RequestBody Director updatedDirector) {
        Director director = directorService.updateDirector(id, updatedDirector);
        return ResponseEntity.ok().body(director);
    }

    // delete
    @DeleteMapping("/directors/{id}")
    public ResponseEntity<Void> deleteDirector(@PathVariable(value = "id") Integer id) {
        directorService.deleteDirector(id);
        return ResponseEntity.noContent().build();
    }


}
