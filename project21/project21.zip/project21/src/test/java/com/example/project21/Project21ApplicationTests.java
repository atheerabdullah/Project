package com.example.project21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project21ApplicationTests {

    @Test
    void contextLoads() {
    }

}
